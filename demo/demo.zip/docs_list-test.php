<!doctype html public "-//W3C//DTD html 4.0 //en">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>auto doc list</title>
		</head>
	<body>	 
	 <br />
	 <br />


<?php
	/**
	 *  license LGPL 
	 * checkup Database
	*/		
 include_once(dirname(__FILE__)."/commonSQL.php");	
	
  // TODO update: Maps  page -> url
 $toUrl = array (
    "test_page" => "odtReportSQL-test.php",
 );
     
					  
		echo "<h2>Documents on this application (test odtReportSQL)</h2><br>";
    $query = "SELECT shortName, page, position FROM odt_reports ORDER BY position";
		$prints=sqlArrayTot($query);
		  
	  print(  "<OL>");
    foreach($prints as $document){
// TODO update: insert hair on list on defined 'position' (if required to group documents)
			     if ($document['position'] == 10)
				         print ('<hr>');
// end todo          
			     $nome = eval($document['shortName']);
			  	 print(  '<li><a href="'.$toUrl[$document['page']].'"><b>'.$nome.'</b></a></li>');
			  }
			 print(  "<hr> </OL><br><br>");	 	  
	 
?>
</body>
</html>
	