<?php
include(dirname(__FILE__)."/commonSQL.php");	
movePage(100,'./odtReportSQL-test.php');
 ?>