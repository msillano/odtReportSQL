<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <meta name="generator"
    content="HTML Tidy for HTML5 (experimental) for Windows https://github.com/w3c/tidy-html5/tree/c63cc39" />
    
  <?php 
       /**
        *  Test of odtReportSQL
        *  
        *  data and SQL queries are in DB as for odtphpsql.
        *  One new table (odt_reports) defines templates and user parameters (max 5) 
        *  odtReportSQL does all work: HTML user interface an document creation.
        *
        *  license LGPL 
        *  author Marco Sillano  (marco.sillano@gmail.com)
        */ 
    include(dirname(__FILE__)."/odtReportSQL.php");
    ?>
    <title>test03</title>
  </head>
  <body>
    <h3>Test odtReportSQL</h3>
    <table>
      <tr>
        <td>
        <hr />This simple test uses 
        <b>odtReportSQL</b>.
        <ul>
          <li>
            <i>Uses the template 
            <a target="_blank" href="templates/test01.odt">test01.odt</a></i>
          </li>
          <li>
            <i>The user interface is defined in a DB table (odt_reports) for all templates</i>
          </li>
        </ul>
        <br />
        <!-- This call builds the HTML for parameters user interface and the 'Go' button for all
     documents defined for this page (test_page) ordered by 'position' field -->
         <?php echo getReportMenu('test_page'); ?></td>
        <td>
          <img src="./img/shot03.png" />
        </td>
      </tr>
    </table>
    <hr />
    <h3>About odtReportSQL:</h3>
    <ol>
      <li>Test: debug mode for template 
      <a href="odtReportSQL-test.php?action=debug&amp;ID=1">test01</a> .</li>
      <li>Test: direct call to doReport for template 
      <a href="odtReportSQL.php?action=build&amp;ID=1&amp;key1=2">test01</a> ("odtReportSQL.php?action=build&ID=1&key1=2" => 2 Blocks).</li>
      <li>Test: auto index page of all 
      <a href='docs_list-test.php'>documents availables</a> on any application.</li>
    </ol>
    <hr />
    <center>
    <a href= "./odtphp-test.php"> test odtphp</a> &nbsp; &nbsp;|&nbsp;&nbsp; <a 
    href= "./odtphpsql-test.php"> test odtphpsql</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a 
    href= "./odtReportSQL-test.php"> test odtReportSQL</a> 
    </center>
    <hr />
  </body>
</html>
