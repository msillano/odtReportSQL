<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <meta name="generator"
    content="HTML Tidy for HTML5 (experimental) for Windows https://github.com/w3c/tidy-html5/tree/c63cc39" />
<?php 
   /**
    *  Test of odtphp
    *  
    *  At this low level, all data structures must be build programmatically.
    * 
    *  license LGPL 
    *  author Marco Sillano  (marco.sillano@gmail.com)
    */ 


include(dirname(__FILE__)."/odtphp.php");
     
// echo '<pre>';
// echo  print_r($_GET);  
// echo '</pre>';			
$download = '';   
if ( array_key_exists('do', $_GET)) {
 processTemplate();	   
 $download = '<a href= "reports/test01-processed.odt"> download document</a>'; 
}
     
function processTemplate(){
   
// start process
    $template = dirname(__FILE__)."/templates/test01.odt";      // the template file
    $outputFile = dirname(__FILE__)."/reports/test01-processed.odt";      // the output file
    
    $newdoc = new  Odtphp($template);    
      
// set field/values pair
    $newdoc->assign("date",  date("d/N/Y")); // basic field mapping	    
    
// set blocks (root)
   $newdoc->assignBlock("myblock", array(array('count' => 'First'),          // 2 values: block will be duplicated
                                          array('count' => 'Second')));
   $newdoc->assignBlock("dir", array(array('adir' => 'C:\\programs'),        // 2 values: block will be duplicated
                                     array('adir' => 'C:\\documents')));
                                          
// set nested blocks (one for any value of 'adir')
   $newdoc->assignNestedBlock("file",array(array('afile' => 'command.com', 'asize' => '34 KB'), 
                                           array('afile' => 'paint.exe', 'asize' => '5678 KB')),array("dir"=>1));  // data for first 'dir' block
   $newdoc->assignNestedBlock("file",array(array('afile' => 'readme.txt', 'asize' => '833  B'), 
                                          array('afile' => 'odtphp.doc', 'asize' =>  '134 KB'),
                                          array('afile' => 'image.jpeg', 'asize' => ' 78 KB')),array("dir"=>2));  // data for second 'dir' block
                                           
// set photo, pictures
    $newdoc->assign("img_photo",  "img/newimg.png"); // basic image mapping	 
    
// does all processes
    $newdoc->saveODT($outputFile) ;
}    
    ?>
  <title>test01</title>
  </head>
  <body>
  <h3>Test odtphp </h3>
  <hr />This simple test uses only <b>odtphp</b>. 
  <ul>
  <li><i>The data are defined programmatically in php</i>
  </ul>
  <br />
  <br />
  <form action="odtphp-test.php" method="get">
  <ol>
    <li>Uses the template
    <a target="_blank" href="templates/test01.odt">test01.odt</a>
    <br /></li>
    <li>Changes the field <CODE>today</CODE></li>
    <li>Makes 2 blocks <CODE>myblock</CODE></li>
    <li>Makes 2 blocks <CODE>dir</CODE> and inside makes more blocks <CODE>file</CODE></li>
    <li>Replaces the <CODE>img_photo</CODE></li>
  </ol>
  <input type="submit" value = "Create document" name="do">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $download; ?> 
    </form>
  <hr>
  <center><a href= "./odtphp-test.php"> test odtphp</a> &nbsp; &nbsp;|&nbsp;&nbsp; <a href= "./odtphpsql-test.php"> test odtphpsql</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href= "./odtReportSQL-test.php"> test odtReportSQL</a> </center>
  <hr>
  </body>

</html>
