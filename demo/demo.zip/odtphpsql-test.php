<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <meta name="generator"
    content="HTML Tidy for HTML5 (experimental) for Windows https://github.com/w3c/tidy-html5/tree/c63cc39" />
<?php 
       /**
        *  Test of odtphpsql
        *  
        *  data and SQL queries are in DB
        * 
        *  license LGPL 
        *  author Marco Sillano  (marco.sillano@gmail.com)
        */ 

    include(dirname(__FILE__)."/odtphpsql.php");    
    $download = '';  

    if ( array_key_exists('do', $_GET)) {
     processTemplate();       
    }
         
    function processTemplate(){
       global $download;
    // start process
        $templateID = 'test01';                                               // templateID == name file
        $template = dirname(__FILE__)."/templates/test01.odt";                // the template file   (note: use / also in WIN)
        $outputFile = dirname(__FILE__)."/reports/test01-processed.odt";      // the output file
        $name = basename($outputFile, ".odt");
        
       $phpsql = new  Odtphpsql($template);                            //  constructor
       $phpsql->assign("img_photo",  "/img/newimg.png");              //  basic direct field mapping       (used here for photo in place of DB)
       $phpsql->assign("key1",  "2");                                  //  used as limit number of blocks
       $odt_queriesArray =  $phpsql->getArrayQueries($templateID);     //  gets the descriptors for this template
       $phpsql->assignAllSQL($odt_queriesArray );                      //  sql fields and blocks definitions via $odt_queriesArray         
     // does all processes
     //  $phpsql->saveODT($outputFile);                                                          //  optional save
             $phpsql->downloadODT($name);                                                        //  and/or send to client  
       $download = $phpsql->replaceMacros('New document sended (#now#)');
      }    
      ?>
    <title>test02</title>
  </head>
  <body>
  <h3>Test odtphp + odtphpsql</h3>
  <hr />This simple test uses only 
  <b>odtphp</b> and 
  <b>odtphpsql</b>.
  <ul>
    <li>
      <i>Uses the template 
      <a target="_blank" href="templates/test01.odt">test01.odt</a></i>
    </li>
    <li>
      <i>The data are defined in a DB, in one or more tables (test_data, test_count)</i>
    </li>
    <li>
      <i>The queries are defined in a DB table (odt_queries) for all templates</i>
    </li>
  </ul>
  <table border="0" summary="">
    <tr>
      <td>
        <img src="img/shot01.png" width="409" height="136" alt="" border="0" />
      </td>
      <td>�
      <img src="img/shot02.png" width="283" height="158" alt="" border="0" /></td>
    </tr>
  </table>
  <br />
  <form action="odtphpsql-test.php" method="get">
  <input type="submit" value="Create document" name="do" />�����<?php echo $download; ?></form>
  <hr />
  <center>
    <a href= "./odtphp-test.php"> test odtphp</a> &nbsp; &nbsp;|&nbsp;&nbsp; <a 
    href= "./odtphpsql-test.php"> test odtphpsql</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a 
    href= "./odtReportSQL-test.php"> test odtReportSQL</a> 
  </center> 
  <hr /></body>
</html>
