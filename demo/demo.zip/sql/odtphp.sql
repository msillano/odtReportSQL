-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generato il: 19 apr, 2017 at 06:41 PM
-- Versione MySQL: 5.0.45
-- Versione PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `odtphp`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `odt_queries`
--

DROP TABLE IF EXISTS `odt_queries`;
CREATE TABLE IF NOT EXISTS `odt_queries` (
  `ID` int(11) NOT NULL auto_increment COMMENT 'key auto',
  `templateID` char(80) NOT NULL COMMENT 'template name',
  `block` char(40) default NULL COMMENT 'only if block, name',
  `parent` char(40) default NULL COMMENT 'only if nested block, name',
  `query` varchar(16000) NOT NULL COMMENT 'SQL query',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `position` (`templateID`,`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='fields and blocks queries definitions';

--
-- Dump dei dati per la tabella `odt_queries`
--

INSERT INTO `odt_queries` (`ID`, `templateID`, `block`, `parent`, `query`) VALUES
(10, 'test01', 'myblock', NULL, 'SELECT  CONCAT(UPPER(SUBSTR(count,1,1)), SUBSTR(count,2)) AS ''count'' FROM test_count ORDER BY value LIMIT #key1#'),
(20, 'test01', 'dir', NULL, 'SELECT DISTINCT adir FROM test_data'),
(30, 'test01', 'file', 'dir', 'SELECT afile, asize FROM test_data WHERE adir = "#0#"'),
(1, 'test01', NULL, NULL, 'SELECT ''./img/newimg.png'' AS ''img_photo''');

-- --------------------------------------------------------

--
-- Struttura della tabella `odt_reports`
--

DROP TABLE IF EXISTS `odt_reports`;
CREATE TABLE IF NOT EXISTS `odt_reports` (
  `ID` int(11) NOT NULL auto_increment COMMENT 'index auto',
  `page` char(60) NOT NULL COMMENT 'the destination page ',
  `position` int(11) unsigned NOT NULL COMMENT 'order index',
  `templateID` char(60) NOT NULL COMMENT 'the file name (.odt)',
  `show` varchar(500) default NULL COMMENT 'php: returns true|false',
  `outmode` enum('send','save','send_save') NOT NULL default 'send' COMMENT 'Document destination',
  `outfilepath` varchar(200) default NULL COMMENT 'php: return file name',
  `shortName` char(250) default NULL COMMENT 'php: return short name',
  `description` varchar(500) default NULL COMMENT 'php: returns description (HTML)',
  `key1type` enum('hidden','HTML','list','radio','date','foreach') default NULL COMMENT 'the key type',
  `key1name` char(60) default NULL COMMENT 'the key name (HTML)',
  `key1value` varchar(2500) default NULL COMMENT 'php|SELECT query',
  `key2type` enum('hidden','HTML','list','radio','date','foreach') default NULL COMMENT 'the key type',
  `key2name` char(60) default NULL COMMENT 'the key name (HTML)',
  `key2value` varchar(2500) default NULL COMMENT 'php|SELECT query',
  `key3type` enum('hidden','HTML','list','radio','date') default NULL COMMENT 'the key type',
  `key3name` char(60) default NULL COMMENT 'the key name (HTML)',
  `key3value` varchar(2500) default NULL COMMENT 'php|SELECT query',
  `key4type` enum('hidden','HTML','list','radio','date') default NULL COMMENT 'the key type',
  `key4name` char(60) default NULL COMMENT 'the key name (HTML)',
  `key4value` varchar(2500) default NULL COMMENT 'php|SELECT query',
  `key5type` enum('hidden','HTML','list','radio','date') default NULL COMMENT 'the key type',
  `key5name` char(60) default NULL COMMENT 'php|SELECT query',
  `key5value` varchar(2500) default NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `position` (`position`),
  KEY `page` (`page`,`position`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Definizione reports';

--
-- Dump dei dati per la tabella `odt_reports`
--

INSERT INTO `odt_reports` (`ID`, `page`, `position`, `templateID`, `show`, `outmode`, `outfilepath`, `shortName`, `description`, `key1type`, `key1name`, `key1value`, `key2type`, `key2name`, `key2value`, `key3type`, `key3name`, `key3value`, `key4type`, `key4name`, `key4value`, `key5type`, `key5name`, `key5value`) VALUES
(1, 'test_page', 10, 'test01', 'return true;', 'send', 'return $baseDir.''/reports/test01_done.odt'';', 'return  ''Test document #1'';', 'return ''This document presents Fields, Blocks, Nested blocks and Photos. <br> The number of Blocks is variable by user.'';', 'list', 'Number of repeated Blocks:', 'return array(0,1,2,3,4,5,6,7,8,9);', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'test_page', 11, 'test01', 'return true;', 'send', 'return $baseDir."/reports/dummy_".$key2."_done.odt";', 'return  ''dummy (saves)'';', 'return ''Only to show more available options on UI <br>and to test <code>foreach  key2type </code> to make 3 documents'';', 'radio', 'Repetition factor:', 'return array(''1'' => ''One'',''2'' => ''Two'',''3''=>''Three'');', 'foreach', 'auto', 'SELECT value FROM test_count LIMIT 3', 'date', 'Assurance ends:', '%x', 'list', 'Chose a number:', '@mylist.csv', 'HTML', 'Enter a name:', 'return "<input type=''text'' name=''key5''>";');

-- --------------------------------------------------------

--
-- Struttura della tabella `test_count`
--

DROP TABLE IF EXISTS `test_count`;
CREATE TABLE IF NOT EXISTS `test_count` (
  `value` int(2) NOT NULL,
  `count` char(16) NOT NULL,
  PRIMARY KEY  (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `test_count`
--

INSERT INTO `test_count` (`value`, `count`) VALUES
(1, 'firsth'),
(2, 'second'),
(3, 'third'),
(4, 'fourth'),
(5, 'fifth'),
(6, 'sixth'),
(7, 'seventh'),
(8, 'eighth'),
(9, 'ninth'),
(10, 'tenth');

-- --------------------------------------------------------

--
-- Struttura della tabella `test_data`
--

DROP TABLE IF EXISTS `test_data`;
CREATE TABLE IF NOT EXISTS `test_data` (
  `id` int(11) NOT NULL auto_increment COMMENT 'index',
  `adir` char(80) NOT NULL COMMENT 'directory name',
  `afile` char(80) NOT NULL COMMENT 'file name',
  `asize` char(10) NOT NULL COMMENT 'file size',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `test_data`
--

INSERT INTO `test_data` (`id`, `adir`, `afile`, `asize`) VALUES
(1, 'C:/programs', 'command.com', '34 KB'),
(2, 'C:/programs', 'paint.exe', '5678 KB'),
(3, 'C:/documents', 'readme.txt', '833 B'),
(4, 'C:/documents', 'odtphp.doc', '134 KB'),
(5, 'C:/documents', 'image.jpeg', '78 KB');
